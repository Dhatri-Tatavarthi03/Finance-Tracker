import React, { useState } from 'react';
import { FinancialData } from '../../types/finance';

const months = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

interface FinanceFormProps {
  onSubmit: (data: FinancialData) => void;
}

export default function FinanceForm({ onSubmit }: FinanceFormProps) {
  const [formData, setFormData] = useState<FinancialData>({
    month: months[new Date().getMonth()],
    income: { salary: 0, freelance: 0, rental: 0, investment: 0, other: 0 },
    expenses: {
      rent: 0, groceries: 0, transport: 0, utilities: 0,
      healthcare: 0, loans: 0, entertainment: 0, creditCard: 0, miscellaneous: 0
    },
    savings: {
      fixedDeposits: 0, mutualFunds: 0, savingsAccount: 0,
      retirement: 0, cashInHand: 0
    },
    budget: { limit: 0, targetSavings: 0 }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-lg shadow">
      <div className="space-y-4">
        <h3 className="text-lg font-medium leading-6 text-gray-900">Monthly Financial Entry</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-700">Select Month</label>
          <select
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            value={formData.month}
            onChange={(e) => setFormData({ ...formData, month: e.target.value })}
          >
            {months.map((month) => (
              <option key={month} value={month}>{month}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <h4 className="text-md font-medium text-gray-900">Income</h4>
            <div className="space-y-2">
              {Object.entries(formData.income).map(([key, value]) => (
                <div key={key}>
                  <label className="block text-sm font-medium text-gray-700 capitalize">
                    {key}
                  </label>
                  <input
                    type="number"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    value={value}
                    onChange={(e) => setFormData({
                      ...formData,
                      income: { ...formData.income, [key]: Number(e.target.value) }
                    })}
                  />
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-md font-medium text-gray-900">Expenses</h4>
            <div className="space-y-2">
              {Object.entries(formData.expenses).map(([key, value]) => (
                <div key={key}>
                  <label className="block text-sm font-medium text-gray-700 capitalize">
                    {key}
                  </label>
                  <input
                    type="number"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    value={value}
                    onChange={(e) => setFormData({
                      ...formData,
                      expenses: { ...formData.expenses, [key]: Number(e.target.value) }
                    })}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-md font-medium text-gray-900">Savings & Investments</h4>
          <div className="grid grid-cols-2 gap-4">
            {Object.entries(formData.savings).map(([key, value]) => (
              <div key={key}>
                <label className="block text-sm font-medium text-gray-700 capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </label>
                <input
                  type="number"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  value={value}
                  onChange={(e) => setFormData({
                    ...formData,
                    savings: { ...formData.savings, [key]: Number(e.target.value) }
                  })}
                />
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-md font-medium text-gray-900">Budget Details</h4>
          <div className="grid grid-cols-2 gap-4">
            {Object.entries(formData.budget).map(([key, value]) => (
              <div key={key}>
                <label className="block text-sm font-medium text-gray-700 capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </label>
                <input
                  type="number"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  value={value}
                  onChange={(e) => setFormData({
                    ...formData,
                    budget: { ...formData.budget, [key]: Number(e.target.value) }
                  })}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="pt-5">
        <button
          type="submit"
          className="w-full inline-flex justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
        >
          Submit Financial Data
        </button>
      </div>
    </form>
  );
}