import React from 'react';
import { ArrowUpIcon, ArrowDownIcon } from '@heroicons/react/24/solid';

interface InsightCardProps {
  title: string;
  amount: number;
  change: number;
  type: 'income' | 'expense' | 'savings';
}

export default function InsightCard({ title, amount, change, type }: InsightCardProps) {
  const getColor = () => {
    switch (type) {
      case 'income':
        return 'bg-green-100 text-green-800';
      case 'expense':
        return 'bg-red-100 text-red-800';
      case 'savings':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-500 truncate">{title}</p>
            <p className="mt-1 text-3xl font-semibold text-gray-900">₹{amount.toLocaleString()}</p>
          </div>
        </div>
        <div className="mt-4">
          <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium ${getColor()}`}>
            {change >= 0 ? (
              <ArrowUpIcon className="-ml-1 mr-0.5 h-4 w-4" />
            ) : (
              <ArrowDownIcon className="-ml-1 mr-0.5 h-4 w-4" />
            )}
            {Math.abs(change)}%
          </div>
          <span className="ml-2 text-sm text-gray-500">from last month</span>
        </div>
      </div>
    </div>
  );
}