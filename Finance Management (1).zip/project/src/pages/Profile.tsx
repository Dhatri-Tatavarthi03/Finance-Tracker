import React, { useState } from 'react';
import ProfileForm from '../components/Profile/ProfileForm';
import { UserProfile } from '../types/finance';

export default function Profile() {
  const [profile, setProfile] = useState<UserProfile>({
    fullName: 'John Doe',
    age: 30,
    occupation: 'Software Engineer',
    annualIncome: 1200000,
    preferredCurrency: 'INR'
  });

  const handleProfileUpdate = (updatedProfile: UserProfile) => {
    setProfile(updatedProfile);
    // Here you would typically send this data to your backend
    console.log('Profile updated:', updatedProfile);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Profile Settings</h1>
      <ProfileForm
        profile={profile}
        onUpdate={handleProfileUpdate}
      />
    </div>
  );
}