import React, { useState } from 'react';
import FinanceForm from '../components/Dashboard/FinanceForm';
import InsightCard from '../components/Dashboard/InsightCard';
import { FinancialData } from '../types/finance';

export default function Dashboard() {
  const [insights, setInsights] = useState({
    totalIncome: 75000,
    totalExpenses: 45000,
    totalSavings: 30000,
    incomeChange: 5,
    expenseChange: -2,
    savingsChange: 8
  });

  const handleFormSubmit = (data: FinancialData) => {
    // Here you would typically send this data to your backend
    console.log('Form submitted:', data);
    
    // Update insights based on new data
    const totalIncome = Object.values(data.income).reduce((a, b) => a + b, 0);
    const totalExpenses = Object.values(data.expenses).reduce((a, b) => a + b, 0);
    const totalSavings = Object.values(data.savings).reduce((a, b) => a + b, 0);

    setInsights({
      totalIncome,
      totalExpenses,
      totalSavings,
      incomeChange: 5, // These would typically be calculated based on previous month's data
      expenseChange: -2,
      savingsChange: 8
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <InsightCard
          title="Total Income"
          amount={insights.totalIncome}
          change={insights.incomeChange}
          type="income"
        />
        <InsightCard
          title="Total Expenses"
          amount={insights.totalExpenses}
          change={insights.expenseChange}
          type="expense"
        />
        <InsightCard
          title="Total Savings"
          amount={insights.totalSavings}
          change={insights.savingsChange}
          type="savings"
        />
      </div>

      <div className="bg-white rounded-lg shadow">
        <div className="p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Enter Monthly Financial Data</h2>
          <FinanceForm onSubmit={handleFormSubmit} />
        </div>
      </div>
    </div>
  );
}