import React, { useState } from 'react';
import FinancialChart from '../components/Reports/FinancialChart';

export default function Reports() {
  const [chartData] = useState({
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    income: [65000, 70000, 75000, 72000, 75000, 78000],
    expenses: [45000, 48000, 46000, 48000, 47000, 49000],
    savings: [20000, 22000, 29000, 24000, 28000, 29000],
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Financial Reports</h1>
      
      <div className="grid grid-cols-1 gap-6">
        <FinancialChart data={chartData} />
        
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Monthly Summary</h2>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-green-800">Average Income</h3>
                <p className="mt-2 text-2xl font-semibold text-green-900">
                  ₹{(chartData.income.reduce((a, b) => a + b, 0) / chartData.income.length).toLocaleString()}
                </p>
              </div>
              
              <div className="bg-red-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-red-800">Average Expenses</h3>
                <p className="mt-2 text-2xl font-semibold text-red-900">
                  ₹{(chartData.expenses.reduce((a, b) => a + b, 0) / chartData.expenses.length).toLocaleString()}
                </p>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-blue-800">Average Savings</h3>
                <p className="mt-2 text-2xl font-semibold text-blue-900">
                  ₹{(chartData.savings.reduce((a, b) => a + b, 0) / chartData.savings.length).toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}