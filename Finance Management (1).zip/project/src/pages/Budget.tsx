import React, { useState } from 'react';
import BudgetChart from '../components/Budget/BudgetChart';
import { Budget } from '../types/finance';

export default function BudgetPage() {
  const [budgetData] = useState<Budget[]>([
    { category: 'Rent', planned: 15000, actual: 15000 },
    { category: 'Groceries', planned: 8000, actual: 9500 },
    { category: 'Transport', planned: 3000, actual: 2800 },
    { category: 'Utilities', planned: 5000, actual: 4800 },
    { category: 'Entertainment', planned: 4000, actual: 6000 },
  ]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Budget Overview</h1>
      <BudgetChart data={budgetData} />
      
      <div className="mt-6 bg-white shadow rounded-lg">
        <div className="p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Budget Summary</h2>
          <div className="space-y-4">
            {budgetData.map((item) => {
              const difference = item.actual - item.planned;
              const isOverBudget = difference > 0;
              
              return (
                <div key={item.category} className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-500">{item.category}</span>
                  <div className="text-right">
                    <p className="text-sm text-gray-900">
                      Actual: ₹{item.actual.toLocaleString()} / Planned: ₹{item.planned.toLocaleString()}
                    </p>
                    <p className={`text-sm ${isOverBudget ? 'text-red-600' : 'text-green-600'}`}>
                      {isOverBudget ? 'Over by' : 'Under by'} ₹{Math.abs(difference).toLocaleString()}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}