import React, { useState } from 'react';
import TransactionList from '../components/Transactions/TransactionList';
import { Transaction } from '../types/finance';

export default function Transactions() {
  const [transactions] = useState<Transaction[]>([
    {
      id: '1',
      date: new Date(),
      category: 'Rent',
      amount: 15000,
      type: 'expense',
      description: 'Monthly Rent'
    },
    {
      id: '2',
      date: new Date(),
      category: 'Salary',
      amount: 75000,
      type: 'income',
      description: 'Monthly Salary'
    },
    // Add more sample transactions here
  ]);

  const handleFilter = (category: string) => {
    console.log('Filtering by category:', category);
    // Implement filtering logic here
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Transactions</h1>
      <TransactionList
        transactions={transactions}
        onFilter={handleFilter}
      />
    </div>
  );
}