export interface Transaction {
  id: string;
  date: Date;
  category: string;
  amount: number;
  type: 'income' | 'expense';
  description: string;
}

export interface Budget {
  category: string;
  planned: number;
  actual: number;
}

export interface UserProfile {
  fullName: string;
  age: number;
  occupation: string;
  annualIncome: number;
  preferredCurrency: string;
}

export interface FinancialData {
  month: string;
  income: {
    salary: number;
    freelance: number;
    rental: number;
    investment: number;
    other: number;
  };
  expenses: {
    rent: number;
    groceries: number;
    transport: number;
    utilities: number;
    healthcare: number;
    loans: number;
    entertainment: number;
    creditCard: number;
    miscellaneous: number;
  };
  savings: {
    fixedDeposits: number;
    mutualFunds: number;
    savingsAccount: number;
    retirement: number;
    cashInHand: number;
  };
  budget: {
    limit: number;
    targetSavings: number;
  };
}